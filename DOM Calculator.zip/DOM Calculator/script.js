let currentInput = '';
let currentOperation = null;

function appendToDisplay(value) {
  currentInput += value;
  document.getElementById('display').value = currentInput;
}

function clearDisplay() {
  currentInput = '';
  document.getElementById('display').value = '';
}

function performOperation(operator) {
  if (currentInput !== '') {
    currentOperation = operator;
    appendToDisplay(` ${operator} `);
  }
}

function calculateResult() {
  if (currentInput !== '') {
    const expression = currentInput.trim();
    const operands = expression.split(' ');
    const num1 = parseFloat(operands[0]);
    const num2 = parseFloat(operands[2]);
    let result;

    switch (currentOperation) {
      case '+':
        result = num1 + num2;
        break;
      case '-':
        result = num1 - num2;
        break;
      case '*':
        result = num1 * num2;
        break;
      case '/':
        result = num1 / num2;
        break;
    }

    clearDisplay();
    document.getElementById('display').value = result;
    currentInput = result.toString();
    currentOperation = null;
  }
}
